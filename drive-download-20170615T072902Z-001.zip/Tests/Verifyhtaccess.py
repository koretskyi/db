
message = 'Attention! The file htaccess was modified!'

with open('htaccess_example') as example, open('htaccess') as origin:
    for x, y in zip(example, origin):
        if x != y:
            print(message)
        else: print('Success')
        break

example.close()
origin.close()
