import requests

sitemap = requests.get('https://dveribelorussii.com.ua/ua/sitemap.xml')
with open('response_sitemap_ua.xml', 'wb') as response: #указать путь к файлу xml
    response.write(sitemap.content)

message = 'Attention! The file https://dveribelorussii.com.ua/ua/sitemap.xml was modified!'

with open('sitemap_ua_origin.xml') as f1, open('response_sitemap_ua.xml') as f2:
    for x, y in zip(f1, f2):
        if x != y:
            print(message)
        else: print('Success')
        break

f1.close()
f2.close()
