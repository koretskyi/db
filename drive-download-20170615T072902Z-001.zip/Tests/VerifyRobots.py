import requests

robots = requests.get('https://dveribelorussii.com.ua/robots.txt')
with open('response_robots.txt', 'wb') as response: #указать путь к файлу xml
    response.write(robots.content)

message = 'Attention! The file https://dveribelorussii.com.ua/robots.txt was modified!'

with open('robots_origin.txt') as f1, open('response_robots.txt') as f2:
    for x, y in zip(f1, f2):
        if x != y:
            print(message)
        else: print('Success')
        break

f1.close()
f2.close()